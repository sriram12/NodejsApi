var config = require('../../config/config');
const sql = require('mssql');

class OTP{       

    static async saveOTP(user_id, otp_code, otp_type){
        let pool = await sql.connect(config.db_config);
        let result = await pool.request()
            .output('id', sql.BigInt, 0)            
            .input('user_id', sql.NVarChar(50), user_id)
            .input('otp_code', sql.NVarChar(10), otp_code)
            .input('otp_type', sql.NVarChar(50), otp_type)            
            .execute('usp_SaveOTP');
        sql.close();
        return result.output;
    }
    
    static async verifyOTP(user_id, otp_code, otp_type){
        let pool = await sql.connect(config.db_config);
        let result = await pool.request()
            .output('result', sql.NVarChar(50), '')            
            .input('user_id', sql.NVarChar(50), user_id)
            .input('otp_code', sql.NVarChar(10), otp_code)
            .input('otp_type', sql.NVarChar(50), otp_type)            
            .execute('usp_VerifyOTP');
        sql.close();
        return result.output;
    }

}

module.exports = { OTP };