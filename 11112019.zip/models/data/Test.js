var config = require('../../config/config');
const sql = require('mssql');

class Test{

    async getAll(){
        let pool = await sql.connect(config.db_config);
        let result = await pool.request()
            .execute('usp_GetAllTestData');
        sql.close();
        return result.recordsets[0];
    }

    async getById(id){
        let pool = await sql.connect(config.db_config);
        let result = await pool.request()
            .input('id', sql.BigInt, id)
            .execute('usp_GetTestDataById');
        sql.close();
        return result.recordsets[0];
    }

}

module.exports = { Test };