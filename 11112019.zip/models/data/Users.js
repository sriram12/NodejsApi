var config = require('../../config/config');
const sql = require('mssql');

class Users{       

    static async register(userDetails){
        let pool = await sql.connect(config.db_config);
        let result = await pool.request()
            .output('user_id', sql.NVarChar(50), userDetails.user_id)
            .output('output_message', sql.NVarChar(250), '')
            .input('registration_type', sql.NVarChar(50), userDetails.registration_type)
            .input('name', sql.NVarChar(100), userDetails.name)
            .input('email', sql.NVarChar(100), userDetails.email)
            .input('mobile', sql.NVarChar(100), userDetails.mobile)
            .input('password', sql.NVarChar(250), userDetails.password)
            .input('social_media_profile_id', sql.NVarChar(250), userDetails.social_media_profile_id)
            .input('gender', sql.NVarChar(50), userDetails.gender)
            .input('roleid', sql.NVarChar(250), userDetails.roleid)
            .input('is_active', sql.Bit, userDetails.is_active)
            .execute('usp_RegisterUser');
        sql.close();
        return result.output;
    } 

    static async getUserDetailsByUserId(user_id){
        let pool = await sql.connect(config.db_config);
        let result = await pool.request()
            .input('user_id', sql.NVarChar(50), user_id)
            .execute('usp_GetUserDetailsByUserId');
        sql.close();
        return result.recordsets[0];
    }

    static async login(loginDetails){
        let pool = await sql.connect(config.db_config);
        let result = await pool.request()
            .output('user_id', sql.NVarChar(50), loginDetails.user_id)
            .output('output_message', sql.NVarChar(250), '')
            .input('login_type', sql.NVarChar(50), loginDetails.login_type)
            .input('email', sql.NVarChar(100), loginDetails.email)
            .input('mobile', sql.NVarChar(100), loginDetails.mobile)
            .input('password', sql.NVarChar(250), loginDetails.password)
            .input('social_media_profile_id', sql.NVarChar(250), loginDetails.social_media_profile_id)
            .execute('usp_ValidateUser');
        sql.close();
        return result.output;
    }

    static async saveToken(user_id, token){
        try{
            let pool = await sql.connect(config.db_config);
            let result = await pool.request()            
                .input('user_id', sql.NVarChar(50), user_id)
                .input('token', sql.NVarChar(sql.MAX), token)
                .execute('usp_SaveToken');
            sql.close();
        }catch(e){
            console.log('error while saving token:', e.toString());
        }
    }

    static async verifyLoginToken(user_id, token){
        let pool = await sql.connect(config.db_config);
        let result = await pool.request()            
            .input('user_id', sql.NVarChar(50), user_id)
            .input('token', sql.NVarChar(sql.MAX), token)
            .execute('usp_VerifyToken');
        sql.close();
        return result.recordsets[0];
    }

}

module.exports = { Users };