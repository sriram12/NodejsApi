
class Utility{       

    static checkNull(value){
        if(!value)
            return '';

        return value;
    }

    static generateOTP(){
        var OTP = Math.floor(100000 + Math.random() * 900000);
        return OTP;
    }

}

module.exports = { Utility };