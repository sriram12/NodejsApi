var jwt = require('jsonwebtoken');
var config = require('../../config/config');
const { Users } = require('../data/Users');

function verifyToken(req, res, next) {
  var token = req.headers['x-access-token'];

  if (!token)
    return res.status(200).send({ success: false, message: 'No token provided.' });
    
  jwt.verify(token, config.secret_key.value, function(err, decoded) {
    if (err){
      //return res.status(500).send({ success: false, message: 'Invalid or expired token. Failed to authenticate.' });
      return res.status(200).send({ success: false, message: 'Invalid or expired token. Failed to authenticate.' });
    }

    //get userid from decoded value and verify database
    let userId = decoded.user_id;
    Users.verifyLoginToken(userId, token).then(function(tokenResult){

      if(tokenResult[0] && tokenResult[0].user_id.toLowerCase() == userId.toLowerCase()){

        // if everything good, save to request for use in other routes
        req.userDetails = decoded;
        next();

      }else{

        return res.status(200).send({ success: false, message: 'Token expired. Failed to authenticate.' });

      }
    }).catch(function(){

      return res.status(200).send({ success: false, message: 'Token expired. Failed to authenticate.' });

    });
        
  });
}

module.exports = verifyToken;