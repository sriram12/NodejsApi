var api = require('../../node_modules/clicksend/api.js');
const config = require('../../config/config');

class ClickSendSMSGateway{  

    static async sendSMS(message, toNumber){

        try{

            //toNumber = '+91' + toNumber;

            var smsMessage = new api.SmsMessage();
            smsMessage.source = "sdk";
            smsMessage.to = toNumber;
            smsMessage.body = message;

            var smsApi = new api.SMSApi(config.clicksend.username, config.clicksend.apikey);

            var smsCollection = new api.SmsMessageCollection();

            smsCollection.messages = [smsMessage];

            // smsApi.smsSendPost(smsCollection).then(function(response) {
            //     return response.body;
            // }).catch(function(err){
            //     return err.body;
            // });

            let sOut = false;
            let result = await smsApi.smsSendPost(smsCollection);
            if(result.body && result.body.response_code == 'SUCCESS'){
                sOut = true;
            }

            return sOut;

        } catch(e) {
            console.log('SMS Error:', e.toString())
            return null;
        }
    }

}

module.exports = { ClickSendSMSGateway };