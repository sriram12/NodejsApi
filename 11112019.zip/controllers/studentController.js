const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const config = require('../config/config');

const { Test } = require('../models/data/Test');

module.exports = {

    getAll: async function(req, res){

        let test = new Test();  
        let result = await test.getAll();        
        res.json({
            success: true,
            data: result
        });       

    },

    getById: async function(req, res){

        let test = new Test();  
        let result = await test.getById(req.params.studentId);  
        res.json({
            success: true,
            data: result
        });

    },

    add: function(req, res){
        
        var data = req.body;
        console.log('Username', data.username);
        console.log('Password', data.password);

        let hashedPassword = bcrypt.hashSync(req.body.password, 8);
        console.log('Hashed Password', hashedPassword);

        var token = null;
        if(data.username == 'sonu' && data.password == '123456'){
            //create jwt token
            token = jwt.sign(
                { 
                    id: 123, 
                    name: 'Sonu', 
                    role: 'admin' 
                }, 
                    config.secret_key.value 
                // ,{
                //     expiresIn: 60 //value in second // expires in 24 hours
                // }
            );
        }        

        console.log('token', token);

        res.json({
            success: true,
            data: data,
            token: token,
            method: 'add'
        });

    },

    update: function(req, res){
        
        var data = req.body;
        console.log(data);

        res.json({
            success: true,
            data: data,
            method: 'update'
        });
    },

    delete: function(req, res){
        
        var data = req.body;
        console.log(data);
        
        res.json({
            success: true,
            data: data,
            method: 'delete'
        });
    }

}