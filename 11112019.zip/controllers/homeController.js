const { ClickSendSMSGateway } = require('../models/common/ClickSendSMSGateway');

module.exports = {

    index: async function(req, res){        

        res.render('home/index', { 
            metatitle: 'Welcome to Virtue Dating App', 
            keyword: '', 
            description: ''
        });
    },

    termsOfServices: function(req, res){
        res.render('home/terms-of-services', { 
            metatitle: 'Terms of Services', 
            keyword: '', 
            description: ''
        });
    },

    privacyPolicy: function(req, res){
        res.render('home/privacy-policy', { 
            metatitle: 'Privacy Policy', 
            keyword: '', 
            description: ''
        });
    },

    cookiesPolicy: function(req, res){
        res.render('home/cookie-policy', { 
            metatitle: 'Cookies Policy', 
            keyword: '', 
            description: ''
        });
    },

    

}