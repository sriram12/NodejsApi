const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const config = require('../config/config');
const validator = require('validator');
const { Utility } = require('../models/common/utility');
const { Users } = require('../models/data/Users');
const { OTP } = require('../models/data/OTP');
const { ClickSendSMSGateway } = require('../models/common/ClickSendSMSGateway');

module.exports = {

    login_old: function(req, res){

        let requestBody = req.body;
        let token = null;
        let success = false;
        let statusCode = 401;
        let message = 'Username or password is incorrect';

        if(requestBody.username == 'dating' && requestBody.password == '123456'){
            success = false;
            statusCode = 200;
            message = 'Login successfull';
            token = jwt.sign({
                "id":"1",
                "name":"Sonu Sharma",
                "email":"sonu@gmrwebteam.com",
                "created_on":"2019-10-30T13:20:47.853Z"
            }, config.secret_key.value);
        }

        res.status(statusCode).json({
            success: success,
            token: token,
            message: message
        }); 

    },

    login: async function(req, res){

        try{

            let requestBody = req.body;
            
            let loginDetails = {
                user_id: '',
                login_type: Utility.checkNull(requestBody.login_type).toLowerCase(), //username_password, mobile_email_otp, social_profile
                email: Utility.checkNull(requestBody.email),
                mobile: Utility.checkNull(requestBody.mobile),
                password: Utility.checkNull(requestBody.password),
                social_media_profile_id: Utility.checkNull(requestBody.social_media_profile_id)
            } 

            let token = null;
            let isValid = true;
            let errorMessage = '';
            let errorCode = '000';
            let otp_sent = null;

            if(validator.isEmpty(loginDetails.login_type) || (loginDetails.login_type != 'username_password' && loginDetails.login_type != 'mobile_email_otp' && loginDetails.login_type != 'social_profile')){

                isValid = false;
                errorMessage = 'Invalid login type';
                errorCode = '002';

            } else if(loginDetails.login_type == 'username_password'){

                if(validator.isEmpty(loginDetails.email)){
                    isValid = false;
                    errorMessage = 'Email is rquired';
                    errorCode = '003';
                } else if(validator.isEmpty(loginDetails.password)){
                    isValid = false;
                    errorMessage = 'Password is rquired';
                    errorCode = '004';
                }

            } else if(loginDetails.login_type == 'social_profile'){

                if(validator.isEmpty(loginDetails.social_media_profile_id)){
                    isValid = false;
                    errorMessage = 'Social media profile id is required';
                    errorCode = '005';
                }

            } else if(loginDetails.login_type == 'mobile_email_otp'){

                if(validator.isEmpty(loginDetails.mobile)){
                    isValid = false;
                    errorMessage = 'Mobile number is required';
                    errorCode = '006';
                }

            }

            if(isValid == true){

                let result = await Users.login(loginDetails);
                loginDetails.user_id = result.user_id;
                let output_message = result.output_message;
                let genratedOTP = '';

                isValid = validator.isEmpty(loginDetails.user_id) ? false : isValid;
                errorMessage = output_message;
                errorCode = (isValid == true) ? '000' : '010';

                let user_basic_details = null;
                if(!validator.isEmpty(loginDetails.user_id) && isValid == true){
                    user_basic_details = await Users.getUserDetailsByUserId(loginDetails.user_id);
                }

                if((loginDetails.login_type == 'username_password' || loginDetails.login_type == 'social_profile') && user_basic_details){                    
                    user_basic_details = user_basic_details[0]
                    //all fine genrate jwt token and return user details with token
                    token = jwt.sign(user_basic_details, config.secret_key.value);
                    //save token in database

                    await Users.saveToken(user_basic_details.user_id, token);

                } else if(loginDetails.login_type == 'mobile_email_otp' && user_basic_details){
                    
                    user_basic_details = user_basic_details[0]

                    // all fine generate OTP and return in API without token
                    genratedOTP = Utility.generateOTP();
                    //first send this code on user's mobile then save into DB
                    let otpResult = await OTP.saveOTP(loginDetails.user_id, genratedOTP, config.otp_type.login);
                    if(otpResult.id == 0){
                        isValid = false;
                        errorMessage = 'OTP not generated';
                        errorCode = '011';
                    }else{
                        let isMessageSent = await ClickSendSMSGateway.sendSMS('OTP for login: ' + genratedOTP + '. This is valid for 5 minutes only', loginDetails.mobile);
                        otp_sent = isMessageSent ? 'yes' : 'no';
                    }
                }

                res.status(200).json({
                    success: isValid,
                    user_details: user_basic_details,
                    token: token,
                    message: errorMessage,
                    errorCode: errorCode,
                    otp_sent: otp_sent
                });

                

            }else{

                res.status(200).json({
                    success: isValid,
                    token: token,
                    message: errorMessage,
                    errorCode: errorCode
                });

            }

        }catch(e){
            res.status(400).json({
                success: false,
                message: e.toString(),
                errorCode: '001'
            });
        }

    },

    register: async function(req, res){
        try{

            let requestBody = req.body;
            
            let userDetails = {
                user_id: '',
                registration_type: Utility.checkNull(requestBody.registration_type).toLowerCase(), //username_password, mobile_email_otp, social_profile
                name: Utility.checkNull(requestBody.name),
                email: Utility.checkNull(requestBody.email),
                mobile: Utility.checkNull(requestBody.mobile),
                password: Utility.checkNull(requestBody.password),
                social_media_profile_id: Utility.checkNull(requestBody.social_media_profile_id),
                gender: Utility.checkNull(requestBody.gender), // value should be 'M' or 'F'
                roleid: config.roles.user,
                is_active: true
            }            

            let token = null;
            let isValid = true;
            let errorMessage = '';
            let errorCode = '000';
            let otp_sent = null;

            if(validator.isEmpty(userDetails.registration_type) || (userDetails.registration_type != 'username_password' && userDetails.registration_type != 'mobile_email_otp' && userDetails.registration_type != 'social_profile')){
                isValid = false;
                errorMessage = 'Invalid registration type';
                errorCode = '002';
            } 
            else if(validator.isEmpty(userDetails.name)){
                isValid = false;
                errorMessage = 'Name is required';
                errorCode = '003';
            }

            if(isValid == true && (userDetails.registration_type == 'username_password' || userDetails.registration_type == 'mobile_email_otp' || userDetails.registration_type == 'social_profile')){

                if(userDetails.registration_type == 'social_profile'){

                    if(validator.isEmpty(userDetails.social_media_profile_id)){
                        isValid = false;
                        errorMessage = 'Social media profile id is required';
                        errorCode = '004';
                    }

                } else{

                    if(validator.isEmpty(userDetails.email)){
                        isValid = false;
                        errorMessage = 'Email is required';
                        errorCode = '005';
                    } else if(!validator.isEmail(userDetails.email)){
                        isValid = false;
                        errorMessage = 'Invalid email';
                        errorCode = '006';
                    } else if(validator.isEmpty(userDetails.mobile)){
                        isValid = false;
                        errorMessage = 'Mobile number is required';
                        errorCode = '007';
                    }

                    if(userDetails.registration_type == 'username_password' && isValid == true){

                        if(validator.isEmpty(userDetails.password)){
                            isValid = false;
                            errorMessage = 'Password is required';
                            errorCode = '008';
                        } else if(userDetails.password.length < 6){
                            isValid = false;
                            errorMessage = 'Minimum 6 characters required for password';
                            errorCode = '009';
                        }
                    }

    
                }

            }


            if(isValid == false){
                
                res.status(200).json({
                    success: isValid,
                    token: token,
                    message: errorMessage,
                    errorCode: errorCode
                });

            } else{

                let result = await Users.register(userDetails);
                userDetails.user_id = result.user_id;
                let output_message = result.output_message;
                let genratedOTP = '';

                isValid = validator.isEmpty(userDetails.user_id) ? false : isValid;
                errorMessage = output_message;
                errorCode = (isValid == true) ? '000' : '010';

                let user_basic_details = null;
                if(!validator.isEmpty(userDetails.user_id) && isValid == true){
                    user_basic_details = await Users.getUserDetailsByUserId(userDetails.user_id);
                }

                if((userDetails.registration_type == 'username_password' || userDetails.registration_type == 'social_profile') && user_basic_details){                    
                    user_basic_details = user_basic_details[0]
                    //all fine genrate jwt token and return user details with token
                    token = jwt.sign(user_basic_details, config.secret_key.value);

                    await Users.saveToken(user_basic_details.user_id, token);

                } else if(userDetails.registration_type == 'mobile_email_otp' && user_basic_details){
                    
                    user_basic_details = user_basic_details[0]

                    // all fine generate OTP and return in API without token
                    genratedOTP = Utility.generateOTP();
                    //first send this code on user's mobile then save into DB

                    let otpResult = await OTP.saveOTP(userDetails.user_id, genratedOTP, config.otp_type.register);
                    if(otpResult.id == 0){
                        isValid = false;
                        errorMessage = 'OTP not generated';
                        errorCode = '011';
                    }else{
                        let isMessageSent = await ClickSendSMSGateway.sendSMS('OTP for login: ' + genratedOTP + '. This is valid for 5 minutes only', userDetails.mobile);
                        otp_sent = isMessageSent ? 'yes' : 'no';
                    }

                }

                res.status(200).json({
                    success: isValid,
                    user_details: user_basic_details,
                    token: token,
                    message: errorMessage,
                    errorCode: errorCode,
                    otp_sent: otp_sent
                });

            }            
        }catch(e){
            res.status(400).json({
                success: false,
                user_details: null,
                token: token,
                message: e.toString(),
                errorCode: '001'
            });
        }
    },

    generateOTP: async function(req, res){

        try{

            let isValid = true;
            let errorMessage = '';
            let errorCode = '000';
            let otp_sent = null;

            let requestBody = req.body;  
            let user_id = Utility.checkNull(requestBody.user_id); 
            let type = Utility.checkNull(requestBody.type); // type can be login or register 
            
            if(validator.isEmpty(user_id)){
                isValid = false;
                errorMessage = 'user id is required';
                errorCode = '002';
            } else if(validator.isEmpty(type)){
                isValid = false;
                errorMessage = 'type is required';
                errorCode = '003';
            } else if(type != 'login' && type != 'register'){
                isValid = false;
                errorMessage = 'Invalid type';
                errorCode = '003';
            }


            if(isValid == true ){

                let mobile_number = '';
                let user_basic_details = null;
                if(!validator.isEmpty(user_id)){
                    user_basic_details = await Users.getUserDetailsByUserId(user_id);
                    mobile_number = user_basic_details[0].mobile_number;
                }

                // all fine generate OTP and return in API
                let genratedOTP = Utility.generateOTP();
                //first send this code on user's mobile then save into DB

                let otpResult = await OTP.saveOTP(user_id, genratedOTP, type);
                if(otpResult.id == 0){                    
                    isValid = false;
                    errorMessage = 'OTP not generated';
                    errorCode = '001';
                }else{                    
                    let isMessageSent = await ClickSendSMSGateway.sendSMS('Your OTP is: ' + genratedOTP + '. This is valid for 5 minutes only', mobile_number);
                    otp_sent = isMessageSent ? 'yes' : 'no';
                }

            }            

            res.status(200).json({
                success: isValid,
                message: errorMessage,
                errorCode: errorCode,
                user_id: user_id,
                otp_sent: otp_sent
            });


        }catch(e){
            res.status(400).json({
                success: false,
                message: e.toString(),
                errorCode: '001'
            });
        }

    },

    verifyOTP: async function(req, res){

        try{

            let requestBody = req.body;   
            let user_id = Utility.checkNull(requestBody.user_id); 
            let otp_code = Utility.checkNull(requestBody.otp_code); 
            let type = Utility.checkNull(requestBody.type); // type can be login or register     
            
            let isValid = false;
            let errorMessage = '';
            let errorCode = '000';
            let token = null;
            let user_basic_details = null;
    
            let otpResult = await OTP.verifyOTP(user_id, otp_code, type);
            if(otpResult.result == 'verified'){
                isValid = true;

                user_basic_details = await Users.getUserDetailsByUserId(user_id);
                if(user_basic_details){
                    user_basic_details = user_basic_details[0];
                    //all fine genrate jwt token and return user details with token
                    token = jwt.sign(user_basic_details, config.secret_key.value);
                    await Users.saveToken(user_basic_details.user_id, token);
                }

            } else {
                isValid = false;
                errorCode = '002';
                errorMessage = 'Invalid or expired OTP';
            }       

            res.status(200).json({
                success: isValid,
                message: errorMessage,
                errorCode: errorCode,
                user_details: user_basic_details,
                token: token
            });
            

        }catch(e){
            res.status(400).json({
                success: false,
                message: e.toString(),
                errorCode: '001'
            });
        }

    }


}