const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const config = require('../config/config');
const validator = require('validator');
const { Utility } = require('../models/common/utility');
const { Users } = require('../models/data/Users');

module.exports = {

    getByUserId: async function(req, res){

        try{
    
            let requestBody = req.body;   
            let user_id = Utility.checkNull(requestBody.user_id);             
            let user_basic_details = await Users.getUserDetailsByUserId(user_id);
            if(user_basic_details){
                user_basic_details = user_basic_details[0]
            }

            res.status(200).json({
                success: true,
                user_details: user_basic_details,
                message: '',
                errorCode: '000'
            });
    
        }catch(e){
            res.status(400).json({
                success: false,
                message: e.toString(),
                errorCode: '001'
            });
        }
    
    }

}
