var verifyToken = require('../models/common/verifyToken');

module.exports = (app) => {

    const homeController = require('../controllers/homeController');
    const studentController = require('../controllers/studentController');
    const loginController = require('../controllers/loginController');
    const userController = require('../controllers/userController');

    app.get('/', homeController.index);
    app.get('/terms-of-services', homeController.termsOfServices);
    app.get('/privacy-policy', homeController.privacyPolicy);
    app.get('/cookies-policy', homeController.cookiesPolicy);


    /* Registration & Login Routing */

    app.post('/api/v1/user/login', loginController.login);
    app.post('/api/v1/user/register', loginController.register);
    app.post('/api/v1/otp/generate', loginController.generateOTP);
    app.post('/api/v1/otp/verify', loginController.verifyOTP);

    /* Registration & Login Routing */

    /* User account related Routing */

    app.post('/api/v1/user/details/getbyuserid', verifyToken, userController.getByUserId);

    /* User account related Routing  */




















    /* Test Routing... Not in use */

    // app.get('/api/students', studentController.getAll)
    //    .get('/api/students/:studentId', verifyToken, studentController.getById)
    //    .post('/api/students', studentController.add)
    //    .put('/api/students/:studentId', studentController.update)
    //    .delete('/api/students/:studentId', studentController.delete);

    // app.post('/api/login-signup-old', loginController.login_old);

    /* Test Routing... Not in use */

}