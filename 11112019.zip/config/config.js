module.exports = {    
    db_config: {
        server: 'SONU',
        database: 'db_VirtueDatingApp',
        user: 'sa',
        password: 'Sonu123!@#'
    },
    secret_key: {
        value: 'zkdgskjfgskdjfgkjsdgfskdgfksdjgfkrpkwewryoweixzmfnklsflsdhlsd'
    }, 
    roles: {
        administrator: '99D868EC-A91E-4F79-B514-D1CB83DAD987',
        user: '29C4CE79-A7F3-4C69-9CF5-51C64B52168B'
    },
    otp_type:{
        login: 'login',
        register: 'register'
    }, 
    clicksend:{
        username: 'virtueapp',
        apikey: 'FCA69700-1BDB-4621-7790-234A325B4531'
    }
}
